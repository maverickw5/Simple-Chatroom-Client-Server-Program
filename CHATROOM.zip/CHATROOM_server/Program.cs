﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Sockets;
using System.Net;
using System.Threading;
using System.Collections;

namespace CHATROOM_server
{
    class Server
    {
        public static Hashtable clientList = new Hashtable();
        static void Main(string[] args)
        {
            Console.WriteLine("CHAT ROOM SERVER");
            Console.WriteLine("Enter IP address:");
            string ip = Console.ReadLine();
            Console.WriteLine("Enter port:");
            string port = Console.ReadLine();
            TcpListener listener = new TcpListener(IPAddress.Parse(ip), Int32.Parse(port));
            TcpClient clientSocket = default(TcpClient);
            listener.Start();
            Console.WriteLine("Waiting for client(s)");
            int counter = 0;
            while (true)
            {
                counter++;
                clientSocket = listener.AcceptTcpClient();
                string datareceived = null;

                NetworkStream nwstream = clientSocket.GetStream();
                byte[] buffer = new byte[clientSocket.ReceiveBufferSize];
                nwstream.Read(buffer, 0, buffer.Length);
                datareceived = Encoding.ASCII.GetString(buffer);
                datareceived = datareceived.Substring(0, datareceived.IndexOf("$"));

                clientList.Add(datareceived, clientSocket);
                broadcast(datareceived + " joined the room ", datareceived, false);
                Console.WriteLine("Client - " + datareceived + " Connected");
                handleClient client = new handleClient();
                client.startClient(clientSocket, datareceived, clientList);
            }
            clientSocket.Close();
            listener.Stop();
        }
        public static void broadcast(string msg, string user, bool flag)
        {
            foreach (DictionaryEntry Item in clientList)
            {
                TcpClient broadcastSocket;
                broadcastSocket = (TcpClient)Item.Value;
                NetworkStream broadcastStream = broadcastSocket.GetStream();
                Byte[] broadcastBytes = null;

                if (flag == true)
                {
                    broadcastBytes = Encoding.ASCII.GetBytes(user + ": " + msg);
                }
                else
                {
                    broadcastBytes = Encoding.ASCII.GetBytes(msg);
                }

                broadcastStream.Write(broadcastBytes, 0, broadcastBytes.Length);
                broadcastStream.Flush();
            }
        }   
        public class handleClient
        {
            TcpClient clientSocket;
            string clNo;
            Hashtable clientList;
            public void startClient(TcpClient inClientSocket, string clineNo, Hashtable cList)
            {
                this.clientSocket = inClientSocket;
                this.clNo = clineNo;
                this.clientList = cList;
                Thread ctThread = new Thread(doChat);
                ctThread.Start();
            }
            public void doChat()
            {
                string dataFromClient = null;
                int requestCount = 0;
                while(true)
                {
                    try
                    {
                        requestCount++;
                        NetworkStream nwstream = clientSocket.GetStream();
                        byte[] buffer = new byte[clientSocket.ReceiveBufferSize];
                        int bytesread = nwstream.Read(buffer, 0, buffer.Length);
                        dataFromClient = Encoding.ASCII.GetString(buffer, 0, bytesread);
                        dataFromClient = dataFromClient.Substring(0, dataFromClient.IndexOf("$"));
                        Console.WriteLine("Client - " + clNo + " : " + dataFromClient);
                        Server.broadcast(dataFromClient, clNo, true);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.ToString());
                    }
                }
            }
        }
    }
}
