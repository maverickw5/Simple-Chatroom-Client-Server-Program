﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Sockets;
using System.Threading;


namespace CHATROOM_client
{
    public partial class Form2 : Form
    {
        TcpClient client = new TcpClient();
        NetworkStream nwstream = default(NetworkStream);
        string readData = null;
        public Form2(string ip, string port, string user)
        {
            InitializeComponent();
            this.Text = ip + ":" + port + " room";
            try
            {
                client.Connect(ip, Int32.Parse(port));
                MessageBox.Show("Connected to Server");
            }
            catch
            {
                MessageBox.Show("Server not found");
                client = null;
                System.Windows.Forms.Application.Exit();
            }
            nwstream = client.GetStream();

            byte[] outStream = Encoding.ASCII.GetBytes(user + "$");
            nwstream.Write(outStream, 0, outStream.Length);
            nwstream.Flush();

            Thread ctThread = new Thread(getMessage);
            ctThread.Start();
        }
        private void getMessage()
        {
            while (true)
            {
                nwstream = client.GetStream();
                byte[] buffer = new byte[client.ReceiveBufferSize];
                int bytesread = nwstream.Read(buffer, 0, buffer.Length);
                string returndata = Encoding.ASCII.GetString(buffer, 0, bytesread);
                readData = "" + returndata;
                msg();
            }
        }
        private void msg()
        {
            if (this.InvokeRequired)
                this.Invoke(new MethodInvoker(msg));
            else
                listBox1.Items.Add(Environment.NewLine + " >> " + readData);
        }
        private void button1_Click(object sender, EventArgs e)
        {
            byte[] outStream = System.Text.Encoding.ASCII.GetBytes(textBox2.Text + "$");
            nwstream.Write(outStream, 0, outStream.Length);
            nwstream.Flush();
            textBox2.Clear();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
